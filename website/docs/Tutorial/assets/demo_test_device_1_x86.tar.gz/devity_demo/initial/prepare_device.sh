#!/bin/bash

#
# (c) Copyright 2021 DEVITY, all rights reserved.
# SPDX-License-Identifier: NONE
#

#
# Prepare files needed to execute DEVITY client.
#


# set default parameter
SERIAL="devity-test1234"
MODEL="devity-client-model"
MANUFACTURER_IP="192.168.0.1"
PORT="8039"
URN="urn:DEVITY:my-device"

parse_args()
{
    OPTIND=1
    while getopts "m:s:i:p:u:" opt; do
        case ${opt} in
            m ) MODEL=$OPTARG
                echo "Got model number : $MODEL"
              ;;
            s ) SERIAL=$OPTARG
                echo "Got serial number : $SERIAL"
              ;;
            i ) MANUFACTURER_IP=$OPTARG
                echo "Got IP : $MANUFACTURER_IP"
              ;;
            p ) PORT=$OPTARG
                echo "Got port : $PORT"
              ;;
            u ) URN=$OPTARG
                echo "Got URN : $URN"
              ;;
            * ) echo "unrecognised flag"
              ;;
        esac
    done
}

parse_args "$@"
echo "setup model number, serial number, IP address and port"
echo -n "${MODEL}" > data/manufacturer_mod.bin
echo -n "${SERIAL}" > data/manufacturer_sn.bin
echo -n "http://${MANUFACTURER_IP}:${PORT}" > data/manufacturer_addr.bin
echo -n "${URN}" > data/urn.dat
echo -n 1024 > data/max_serviceinfo_sz.bin

openssl ecparam -name secp384r1 -genkey -noout -out data/ecdsa384privkey.pem
hxdump_tmp=$(openssl asn1parse < data/ecdsa384privkey.pem | grep "HEX DUMP")
echo ${hxdump_tmp##*:} | xxd -r -p > data/ecdsa384privkey.dat

